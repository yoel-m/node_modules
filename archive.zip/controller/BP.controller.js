sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("sample.com.bpui5.controller.BP",{onInit:function(){}})});
//# sourceMappingURL=BP.controller.js.map