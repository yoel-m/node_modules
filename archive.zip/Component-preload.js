//@ui5-bundle sample/com/bpui5/Component-preload.js
sap.ui.require.preload({
	"sample/com/bpui5/Component.js":function(){
sap.ui.define(["sap/ui/core/UIComponent","sap/ui/Device","sample/com/bpui5/model/models"],function(e,i,t){"use strict";return e.extend("sample.com.bpui5.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments);this.getRouter().initialize();this.setModel(t.createDeviceModel(),"device")}})});
},
	"sample/com/bpui5/controller/App.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("sample.com.bpui5.controller.App",{onInit:function(){}})});
},
	"sample/com/bpui5/controller/BP.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("sample.com.bpui5.controller.BP",{onInit:function(){}})});
},
	"sample/com/bpui5/i18n/i18n.properties":'# This is the resource bundle for sample.com.bpui5\n\n#Texts for manifest.json\n\n#XTIT: Application name\nappTitle=BP UI5\n\n#YDES: Application description\nappDescription=An SAP Fiori application.\r\n#XTIT: Main view title\ntitle=BP UI5',
	"sample/com/bpui5/manifest.json":'{"_version":"1.59.0","sap.app":{"id":"sample.com.bpui5","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"0.0.1"},"title":"{{appTitle}}","description":"{{appDescription}}","resources":"resources.json","sourceTemplate":{"id":"@sap/generator-fiori:basic","version":"1.13.6","toolsId":"bd2ed3d5-63b8-4911-83af-6c82d9942473"},"dataSources":{"mainService":{"uri":"/sap/opu/odata/iwbep/GWSAMPLE_BASIC/","type":"OData","settings":{"annotations":[],"localUri":"localService/metadata.xml","odataVersion":"2.0"}}}},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"flexEnabled":true,"dependencies":{"minUI5Version":"1.124.1","libs":{"sap.m":{},"sap.ui.core":{},"sap.f":{},"sap.suite.ui.generic.template":{},"sap.ui.comp":{},"sap.ui.generic.app":{},"sap.ui.table":{},"sap.ushell":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"sample.com.bpui5.i18n.i18n"}},"":{"dataSource":"mainService","preload":true,"settings":{}}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","async":true,"viewPath":"sample.com.bpui5.view","controlAggregation":"pages","controlId":"app","clearControlAggregation":false},"routes":[{"name":"RouteBP","pattern":":?query:","target":["TargetBP"]}],"targets":{"TargetBP":{"viewType":"XML","transition":"slide","clearControlAggregation":false,"viewId":"BP","viewName":"BP"}}},"rootView":{"viewName":"sample.com.bpui5.view.App","type":"XML","async":true,"id":"App"}}}',
	"sample/com/bpui5/model/models.js":function(){
sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,n){"use strict";return{createDeviceModel:function(){var i=new e(n);i.setDefaultBindingMode("OneWay");return i}}});
},
	"sample/com/bpui5/view/App.view.xml":'<mvc:View controllerName="sample.com.bpui5.controller.App"\n    xmlns:html="http://www.w3.org/1999/xhtml"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><App id="app"></App></mvc:View>\n',
	"sample/com/bpui5/view/BP.view.xml":'<mvc:View controllerName="sample.com.bpui5.controller.BP"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><Page id="page" title="{i18n>title}"><content /></Page></mvc:View>\n'
});
//# sourceMappingURL=Component-preload.js.map
